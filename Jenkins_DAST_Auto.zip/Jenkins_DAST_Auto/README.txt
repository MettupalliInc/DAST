This set of python scripts is to demonstrate the power of DAST scanning through build automation.

*Note*
The scan template to be used has to be created. It cannot be one of the default ones included in
the ASE by default (e.g. Quick and Light Scan or Developer Essentials)
This demo assumes Manual Explore Server is installed in the default location:
C:\Program Files (x86)\IBM\AppScan Manual Explorer

The workflow is kicked off when a build of AltoroJ is started in Jenkins.
Workflow:
1. Build completes in Jenkins
2. Jenkins runs the post build task "python Selenium_StartScan.py dast_auto.config"
3. The script starts the manual explore server
4. The selenium script "Selenium_Altoro_View_AcctDetails.py" is ran. 
	(Traffic is proxied through the manual explore server)
5. The M.E.S stopped and traffic capture is saved as an HTD file in the workspace directory
6. A scan job is created in ASE if one is not already there
7. The starting URL is added to the job (old one is overwritten)
8. The HTD file is deleted.
9. Login type is set to "Automatic"
10. Test credentials are added to the scan job
11. Scan is run
12. Report Pack is run
13. Security issues are extracted from the Security Issues report
14. monkit.xml is updated so that Jenkins can display the graph

The necessary files to this process are:
dast_auto.config - This is the configuration file for the automation. 
	Edit this file to change the behavior of the script 
	(e.g. change the scan template or starting URL)
	The file Selenium_StartScan.py has a function to generate a blank config file
scans.py -  a python library that contains the API calls to ASE
Selenium_Altoro_ViewAcctDetails.py - A selenium script that logs into AltoroJ,
	views the account details of the first account and does a search
Selenium_StartScan.py - a python script that contains the logic described in steps 3-14 above.
	Edit Line #80 to adjust for the Jenkins project folder naming
monkit.xml - a file that Jenkins can consume to display results of our security scanning
geckodriver.log - the auto-generated log file for the geckodriver.
	geckodriver is the driver that allows Selenium to interface with firefox via python


