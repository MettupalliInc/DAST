import configparser
import argparse
import requests
import time
import subprocess
import sys
from scans import *
import os

parser = argparse.ArgumentParser(description='This script records http traffic from a Selenium script to an HTD file, then kicks off a scan in AppScan Enterprise using that HTD file as explore data')
parser.add_argument("configFile", action="store", help="Relative Path to Config File e.g. myConifg.config")
args = parser.parse_args()

config = configparser.ConfigParser(interpolation=configparser.ExtendedInterpolation())
config.read(args.configFile)

manualExplorerUrl = 'http://' + config['MANUAL_EXPLORE_SERVER']['manualexploreserverhost'] + ':' + config['MANUAL_EXPLORE_SERVER']['commandport'] + '/'
htdFileName = "manualExploreData_" + str(int(time.time()))
HAR2HTD_Location = config['MANUAL_EXPLORE_SERVER']['HAR2HTD_Location']
proxy_exec_cmd = config['MANUAL_EXPLORE_SERVER']['proxy_exec_cmd']

def startManualExploreServer(proxy_exec_cmd, manualExploreServerUrl, port,):
    print("Starting Manual Explore Server Listener: " + manualExploreServerUrl + " Port: " + str(port))
    # OLD Manual Explore Server based code
    #params = {"port" : port}
    #r = requests.get(manualExploreServerUrl + 'start', params)
    #print(r.text)
    #if r.text.find("Recording started") == -1:
    #    return False
    #else:
    #    print("Manual Explore Server is now listening")
    #    return True

    # new Automation Proxy Server code

    # start the Automation Proxy Server web app
    exec_proxy_server(proxy_exec_cmd, manualExploreServerUrl)

    # download the certificate
    print("** Downloading self signed root certificate (needed if we are working with https and want to avoid SSL errors)")
    url = manualExploreServerUrl + "Automation/Certificate/"
    response = requests.get(url, verify=False)
    pem_root_ca_str = response.content.decode("utf-8")
    pem_root_ca_file_name = "rootCaPuKey.pem"
    pem_file = open(pem_root_ca_file_name, "w")
    pem_file.write(pem_root_ca_str)
    pem_file.close()
    print("*** Self signed root certificate has been saved as file '" + pem_root_ca_file_name + "'")
        
    # start Automation Proxy Server listening
    print("** Starting proxy on port '%s'" % (port))
    start_url = manualExploreServerUrl + "Automation/StartProxy/" + str(port)
    stop_url = manualExploreServerUrl + "Automation/StopProxy/" + str(port)
    response = requests.post(start_url, verify=False)
    print("*** Proxy Server Response:" + str(response.json()))
    if response.text.find("\"success\":true") == -1:
        if response.text.find("is not available"):
            print ('** Proxy already running, stopping and restarting')
            response = requests.get(stop_url, verify=False)
            response = requests.post(start_url, verify=False)
            print ("** Start command response:" + str(response.json()))
            if response.text.find("\"success\":true") == -1:
                return False
            else:
                return True
    else:
        print("Manual Explore Server is now listening")
        time.sleep(10)
        return True
    
def is_proxy_server_running(manualExploreServerUrl):
    print(manualExploreServerUrl)
    try:
        response = requests.get(manualExploreServerUrl, verify=False)
    except:
        e = sys.exc_info()[0]
        print (e)
        return False
    print(response)
    return response != None and response.status_code == 200

def exec_proxy_server(proxy_exec_cmd, manualExploreServerUrl):
    #attempt to start proxy server
    if not is_proxy_server_running(manualExploreServerUrl):
        r = subprocess.Popen(proxy_exec_cmd, shell=True)
        print ('waiting for proxy server to start')
        time.sleep(20)
        print (r)
        
def stopManualExploreServer(manualExploreServerUrl, port, fileName, HAR2HTD_Location):
    print("Stopping Manual Explore Server...", end="", flush=True)
    # OLD Manual Explore Server code
    #params = {"port" : port, "fileName" : fileName}
    #r = requests.get(manualExploreServerUrl + 'stop', params)
    #print(r.text)
    #if r.text.find("Recording stopped") == -1:
    #    return False
    #else:
    #    print("Success")
    #    print("Saved HTD File: " + fileName + ".htd")
    #    return True

    # new Automation Proxy Server code
    url = manualExploreServerUrl + "Automation/StopProxy/" + str(port)
    response = requests.get(url, verify=False)
    print("*** Proxy Server Response:" + str(response.json()))
    if response.text.find("\"success\":true") == -1:
        return False
    else:
        download_traffic(manualExploreServerUrl,port,fileName)
        convert_traffic_to_htd(HAR2HTD_Location, fileName)
        print("Success")
        print("Saved HTD File: " + fileName + ".htd")
        return True

def download_traffic(manualExploreServerUrl,port,filename):
    print("** Downloading the traffic file")
    url = manualExploreServerUrl + "Automation/Traffic/" + str(port)
    response = requests.get(url, verify=False)
    #self.config.traffic_file_name = "scan.dast.config"
    traffic_file = open(filename, "wb")
    for chunk in response.iter_content(chunk_size=1024):
        if chunk:
            traffic_file.write(chunk)
    traffic_file.close()
    print("*** The traffic has been saved as file '" + filename + "'")

def convert_traffic_to_htd(HAR2HTD_Location, filename):
    cmd = subprocess.run(HAR2HTD_Location + 'HAR2HTD.exe ' + filename + ' ' + filename + '.htd', stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
    if(cmd.returncode != 0):
        print("HAR2HTD Process was terminated")
        HTD_file_name = ""
    else:
        print("HAR2HTD successfully converted file")
        return filename + ".htd"

#kils a process if running e.g. processKill('ManualExploreServer.exe')
def processKill(procName):
    cmd = subprocess.run('c:\windows\system32\cmd.exe /c c:\windows\system32\TASKKILL.exe /F /IM ' + procName, stderr=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
    if(cmd.returncode == 0):
        print("Process " + procName + " was terminated")

def writeBlankConfig():
    blank_config = configparser.ConfigParser()
    blank_config['MANUAL_EXPLORE_SERVER'] = {}
    blank_config['MANUAL_EXPLORE_SERVER']['manualexploreserverhost'] = "localhost"
    blank_config['MANUAL_EXPLORE_SERVER']['commandPort'] = "9999"
    blank_config['MANUAL_EXPLORE_SERVER']['listeningport'] = "19995"

    blank_config['SELENIUM'] = {}
    blank_config['SELENIUM']['scriptCmd'] = "mySeleniumScript.py"

    blank_config['APPSCAN'] = {}
    blank_config['APPSCAN']['templatename'] = "template name"
    blank_config['APPSCAN']['startingurl'] = "http://demo.testfire.net"
    blank_config['APPSCAN']['testusername'] = "jsmith"
    blank_config['APPSCAN']['testpassword'] = "demo1234"
    blank_config['APPSCAN']['scanjobname'] = "scan job name"
    blank_config['APPSCAN']['appid'] = "100"
    blank_config['APPSCAN']['foldername'] = "Automation"
    new_config_file = open("configTemplate.config", "w")
    blank_config.write(new_config_file)

print("===== Starting DAST Automation =====")

print('Start the Manual Explore Server')
# OLD start Manual Explore Server
#kill old manual explore server instance if it is running
#processKill("ManualExploreServer.exe")
#time.sleep(3)
#start the manual explore server process
#mesProc = subprocess.Popen('C:\Program Files (x86)\IBM\AppScan Manual Explorer\ManualExploreServer.exe -host localhost -cmdPort 9999 -recordingsDir "C:\Program Files (x86)\Jenkins\jobs\AltoroJ 3.1.1\workspace" -ignoreCertificateErrors', stdout=subprocess.DEVNULL)
#time.sleep(5)
#print("Manual Explore Server Started: PID " + str(mesProc.pid))

# assume that Automation Proxy Server is running
# add code later to start it if it isn't running

#start manual explore server listener
if(startManualExploreServer(proxy_exec_cmd, manualExplorerUrl, config['MANUAL_EXPLORE_SERVER']['listeningport']) == False):
    sys.exit('Manual Explore Server Not Running. Exiting')
    
time.sleep(3)

#run Selenium Script
print("Running Selenium Script: " + config['SELENIUM']['scriptCmd'])
completedProc = subprocess.run(config['SELENIUM']['scriptCmd'], universal_newlines=True, stdout=subprocess.PIPE)
print("Selenium Script Done")
print("Selenium Script Return Code: " + str(completedProc.returncode))
print(completedProc.stdout)

#stop manual explore server and save htd file
if(stopManualExploreServer(manualExplorerUrl, config['MANUAL_EXPLORE_SERVER']['listeningport'], htdFileName, HAR2HTD_Location) == False):
    sys.exit('Something went wrong stopping the manual explore server. Exiting')

# OLD MES code to stop process, Automation Proxy Server will be left running
#time.sleep(5)
#mesProc.terminate()

#Create a server object
server=ase()
server.setServer('https://localhost/ase') #Set the url for the enterprise server, don't end with a / 
server.logIn('localhost\Administrator','password') #Set the user name and password, and log in
templateId = 0
folderName = config['APPSCAN']['foldername']
templateName = config['APPSCAN']['templatename']
scanName = config['APPSCAN']['scanjobname']
scanFolderId = '0'
appId = config['APPSCAN']['appid']
startingUrl = config['APPSCAN']['startingurl']
testUser = config['APPSCAN']['testusername']
testPassword = config['APPSCAN']['testpassword']

print('Check to see if folder ' + folderName + ' exists')

scanFolderId = server.findFolderByName(folderName)
if(scanFolderId == -1):
    sys.exit('Cannot find folder: ' + folderName + '. Exiting')

print('Folder Found ID: ' + scanFolderId)
print('Checking to see if scan ' + scanName + ' already exists in folder ' + folderName)

scanJobId = server.verifyFolderItemExists(scanName, scanFolderId)
reportPackId = server.verifyFolderItemExists(scanName, scanFolderId, 1)

if(scanJobId == 0):
    print("Not Found. We must create scan from template " + templateName)
    print('Looking for Scan Teamplate: ' + templateName)

    templates = server.getTemplatesList()
    
    for t in templates:
        if(templates[t] == templateName):
            print("Found! Template ID: " + t)
            templateId = t
    if(templateId == 0):
        sys.exit("Template Not Found...Exiting")
    
    print('Create Scan from Template ' + str(templateId))
    r = server.createScan(scanName,'Automated Scan from Jenkins - Based on Selenium Traffic', str(templateId), scanFolderId, appId)
    time.sleep(5)
    scanJobId = server.verifyFolderItemExists(scanName, scanFolderId)
    reportPackId = server.verifyFolderItemExists(scanName, scanFolderId, 1)
    if(scanJobId == 0):
       sys.exit('Scan did not exist and we cannot create one! Exiting')

print(scanName + " already exists")
print('Using Scan Job ' + str(scanJobId))
print('Uploading HTD...', end="", flush=True)
r=server.uploadHTD('./'+htdFileName+'.htd', str(scanJobId))
print("done")

#print("Deleting HTD File: " + htdFileName+'.htd')
#os.remove(htdFileName+'.htd')

#set start URL here
print('Adding starting URL: ' + startingUrl)
server.changeURL(scanJobId, startingUrl)

#set login type to automatic
print("Setting login type to Automatic")
server.changeLoginType(scanJobId, '3')

#set credentials here
print('Adding test credentials: ' + testUser + "/" + testPassword)
server.changeCredentials(scanJobId,testUser,testPassword)

print('Running Scan Job')
#Run scan job
server.runTask('Scan',str(scanJobId),15) 

if(reportPackId == 0):
       sys.exit('Report Pack Not Found... Exiting')

print('Wait for reports to update')
#Wait for reports to update
server.runTask('Results update',str(reportPackId),15) 

#Utility for setting various color is the html table
def color(x):
    return {
        0: "FF0000",
        1: "FF9100",
		2: "FFE600",
		3: "E7E7E7",
		4: "FFB2B2",
		5: "CCFFCC",
		6: "FFFFCC",
        }.get(x, "E7E7E7") 


#Getting report details
print('Getting Report Details')
reports = server.getReportPackList(str(reportPackId))
secIssuesReportId = 0
for r in reports:
    if(reports[r] == 'Security Issues'):
        secIssuesReportId = r
        print('Security Issues Report Found: RID ' + str(r))

issueCount = server.getIssueCount(str(secIssuesReportId))



print()
print(" - Security Issues - ")
print("Critical: " + str(issueCount['Critical']))
print("High: " + str(issueCount['High']))
print("Medium: " + str(issueCount['Medium']))
print("Low: " + str(issueCount['Low']))
print("Information: " + str(issueCount['Information']))

#Create a monkit chart
monkit='<categories>\n<category name="Security findings" scale="No. of Findings">\n<observations>\n'
monkit+='<observation name="Critical">'+str(issueCount['Critical'])+'</observation>\n'
monkit+='<observation name="High">'+str(issueCount['High'])+'</observation>\n'
monkit+='<observation name="Medium">'+str(issueCount['Medium'])+'</observation>\n'
monkit+='<observation name="Low">'+str(issueCount['Low'])+'</observation>\n'
monkit+='<observation name="Information">'+str(issueCount['Information'])+'</observation>\n'
monkit=monkit+'</observations>\n</category>\n</categories>'

f = open('monkit.xml', 'w')
f.write(monkit)
f.close();

server.endSession()
print()
print("Exceptions Caught: " + str(server.connectionErrors))
print("===== End DAST Automation =====")


